import SwiftUI

struct ActivityView: View {
    @StateObject private var viewModel = ActivityViewModel()
    
    var body: some View {
        VStack(spacing: 20) {
            Text("🌐 Live Network Test")
                .font(.title)
                .bold()
            
            Group {
                if viewModel.isLoading {
                    ProgressView()
                        .scaleEffect(1.5)
                } else {
                    VStack(alignment: .leading, spacing: 10) {
                        // Displays the headline/title string from the API
                        Text(viewModel.titleText)
                            .font(.headline)
                            .foregroundColor(.blue)
                        
                        // Displays the body paragraph text if it exists
                        if !viewModel.bodyText.isEmpty {
                            Text(viewModel.bodyText)
                               .font(.body)
                               .foregroundColor(.secondary)
                        }
                    }
                    .padding()
                }
            }
            .frame(minHeight: 160)
            
            Button(action: {
                viewModel.fetchActivity()
            }) {
                Text("Fetch Data From Web")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .disabled(viewModel.isLoading)
        }
        .padding()
    }
}
