//
//  SwiftUICombineApp.swift
//  SwiftUICombine
//
//  Created by Ashwini Choudhar on 03/11/26.
//

import SwiftUI

@main
struct SwiftUICombineApp: App {
    var body: some Scene {
        WindowGroup {
            ActivityView()
        }
    }
}
