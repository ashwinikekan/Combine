//
//  Activity.swift
//  SwiftUICombine
//
//  Created by Ashwini Choudhar on 03/11/26.
//

import Foundation

struct Post: Codable {
    let id: Int
    let title: String
    let body: String
}
