import Foundation
import Combine

class ActivityViewModel: ObservableObject {
    // UI Outlets
    @Published var titleText: String = "Tap below to fetch a live post!"
    @Published var bodyText: String = ""
    @Published var isLoading: Bool = false
    
    private var cancellables = Set<AnyCancellable>()
    
    func fetchActivity() {
        // A guaranteed, live, 100% stable test JSON endpoint URL
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts/1") else { return }
        
        isLoading = true
        bodyText = "" // Reset older body text
        
        URLSession.shared.dataTaskPublisher(for: url)
            .map(\.data) // Grabs the raw payload data stream
            .decode(type: Post.self, decoder: JSONDecoder()) // Parses into our structural Post model
            .receive(on: DispatchQueue.main) // Switches back safely onto the Main Thread for UI redraws
            .sink { [weak self] completion in
                self?.isLoading = false
                if case .failure(let error) = completion {
                    print("❌ Network Failure Trace: \(error)")
                    self?.titleText = "Network Error"
                    self?.bodyText = error.localizedDescription
                }
            } receiveValue: { [weak self] post in
                // Successfully map properties to our outputs
                self?.titleText = post.title.capitalized
                self?.bodyText = post.body
            }
            .store(in: &cancellables) // Persist pipeline life cycle
    }
}
